interface StatsCardsProps {
  stats: {
    totalProducts: number;
    lowCompetition: number;
    highPotential: number;
    shouldTest: number;
    avgRating: number;
    avgTrendScore: number;
  } | null | undefined;
}

export function StatsCards({ stats }: StatsCardsProps) {
  if (!stats) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-white p-6 rounded-lg shadow animate-pulse">
            <div className="h-4 bg-gray-200 rounded mb-2"></div>
            <div className="h-8 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Total Products",
      value: stats.totalProducts,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      icon: "📊"
    },
    {
      title: "Low Competition",
      value: stats.lowCompetition,
      color: "text-green-600",
      bgColor: "bg-green-50",
      icon: "🎯"
    },
    {
      title: "High Potential",
      value: stats.highPotential,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      icon: "💎"
    },
    {
      title: "Test Ready",
      value: stats.shouldTest,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      icon: "🚀"
    },
    {
      title: "Avg Rating",
      value: `${stats.avgRating}⭐`,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      icon: "⭐"
    },
    {
      title: "Trend Score",
      value: `${stats.avgTrendScore}%`,
      color: "text-red-600",
      bgColor: "bg-red-50",
      icon: "🔥"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
      {cards.map((card, index) => (
        <div key={index} className={`${card.bgColor} p-6 rounded-lg border border-opacity-20`}>
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-gray-600">
              {card.title}
            </div>
            <span className="text-lg">{card.icon}</span>
          </div>
          <div className={`text-2xl font-bold ${card.color}`}>
            {card.value}
          </div>
        </div>
      ))}
    </div>
  );
}
