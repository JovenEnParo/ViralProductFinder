import { Doc } from "../../convex/_generated/dataModel";

interface ProductTableProps {
  products: Doc<"products">[];
}

export function ProductTable({ products }: ProductTableProps) {
  if (products.length === 0) {
    return (
      <div className="p-12 text-center text-gray-500">
        <div className="text-6xl mb-4">🤖</div>
        <h3 className="text-xl font-medium mb-2">No viral products found</h3>
        <p className="text-gray-400 mb-6">Use AI Research to discover trending products automatically</p>
        <div className="text-sm text-gray-400">
          💡 Tip: Try different platforms and keywords for better results
        </div>
      </div>
    );
  }

  const getCompetitionColor = (level: string) => {
    switch (level) {
      case "Low": return "bg-green-100 text-green-800 border-green-200";
      case "Medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "High": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getPotentialColor = (level: string) => {
    switch (level) {
      case "High": return "bg-purple-100 text-purple-800 border-purple-200";
      case "Medium": return "bg-blue-100 text-blue-800 border-blue-200";
      case "Low": return "bg-gray-100 text-gray-800 border-gray-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getTrendScoreColor = (score: number) => {
    if (score >= 80) return "text-red-600 bg-red-50";
    if (score >= 60) return "text-orange-600 bg-orange-50";
    if (score >= 40) return "text-yellow-600 bg-yellow-50";
    return "text-gray-600 bg-gray-50";
  };

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    return "⭐".repeat(fullStars) + (hasHalfStar ? "⭐" : "");
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Product & Details
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Viral Factor
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Market Analysis
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Source & Rating
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Recommendation
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {products.map((product) => (
            <tr key={product._id} className="hover:bg-gray-50 transition-colors">
              <td className="px-6 py-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-900">{product.name}</div>
                  <div className="text-xs text-gray-500 max-w-xs line-clamp-2">{product.description}</div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                      {product.category}
                    </span>
                    {product.estimatedPrice && (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                        ${product.estimatedPrice}
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {product.tags.slice(0, 3).map((tag, index) => (
                      <span key={index} className="inline-block bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="space-y-2">
                  <div className="text-sm text-gray-900 max-w-xs">{product.whyViral}</div>
                  <div className="text-xs text-gray-600">
                    <strong>Target:</strong> {product.targetAudience}
                  </div>
                  <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getTrendScoreColor(product.trendScore)}`}>
                    🔥 {product.trendScore}% Trending
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">Competition:</span>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full border ${getCompetitionColor(product.competitionLevel)}`}>
                      {product.competitionLevel}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">Potential:</span>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full border ${getPotentialColor(product.profitabilityPotential)}`}>
                      {product.profitabilityPotential}
                    </span>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="space-y-2">
                  <div className="text-sm">
                    <div className="text-gray-900 font-medium">{product.sourcePlatform}</div>
                    <a 
                      href={product.sourceUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 text-xs underline"
                    >
                      View Source →
                    </a>
                  </div>
                  <div className="text-sm">
                    <div className="flex items-center gap-1">
                      {renderStars(product.rating)}
                      <span className="text-gray-500 text-xs">({product.rating}/5)</span>
                    </div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="space-y-2">
                  <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    product.shouldTest 
                      ? 'bg-green-100 text-green-800 border border-green-200' 
                      : 'bg-red-100 text-red-800 border border-red-200'
                  }`}>
                    {product.shouldTest ? '✅ Test Now' : '❌ Skip'}
                  </div>
                  <div className="text-xs text-gray-600 max-w-xs line-clamp-3">
                    {product.recommendation}
                  </div>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
