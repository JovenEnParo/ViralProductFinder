import { useState } from "react";
import { useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface AIResearchModalProps {
  onClose: () => void;
  onProductsAdded: () => void;
}

export function AIResearchModal({ onClose, onProductsAdded }: AIResearchModalProps) {
  const researchProducts = useAction(api.aiResearch.researchViralProducts);
  const [isResearching, setIsResearching] = useState(false);
  const [results, setResults] = useState<any>(null);
  
  const [formData, setFormData] = useState({
    platforms: ["TikTok", "Instagram", "YouTube"],
    categories: ["Electronics", "Home & Garden", "Health & Beauty"],
    keywords: ["viral", "trending", "gadget"],
    competitionLevel: "Medium",
    count: 10
  });

  const platformOptions = [
    "TikTok", "Instagram", "YouTube", "Facebook Ads", "Reddit", 
    "Google Trends", "Amazon", "AliExpress", "Alibaba", "Etsy", "Shopify"
  ];

  const categoryOptions = [
    "Electronics", "Home & Garden", "Fashion", "Health & Beauty", 
    "Sports & Outdoors", "Pet Supplies", "Kitchen", "Automotive", 
    "Baby & Kids", "Gaming", "Fitness", "Beauty", "Tech Gadgets"
  ];

  const handlePlatformChange = (platform: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        platforms: [...prev.platforms, platform]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        platforms: prev.platforms.filter(p => p !== platform)
      }));
    }
  };

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        categories: [...prev.categories, category]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        categories: prev.categories.filter(c => c !== category)
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.platforms.length === 0) {
      toast.error("Please select at least one platform");
      return;
    }

    setIsResearching(true);
    setResults(null);

    try {
      const result = await researchProducts({
        platforms: formData.platforms,
        categories: formData.categories,
        keywords: formData.keywords,
        competitionLevel: formData.competitionLevel,
        count: formData.count
      });

      setResults(result);
      
      if (result.success && result.productsAdded > 0) {
        toast.success(`Successfully added ${result.productsAdded} viral products!`);
        onProductsAdded();
      } else if (result.success && result.productsAdded === 0) {
        toast.warning("Research completed but no new products were added");
      } else {
        toast.error(result.error || "Research failed");
      }
    } catch (error) {
      toast.error("Failed to research products");
      console.error(error);
    } finally {
      setIsResearching(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">🤖 AI Product Research</h2>
              <p className="text-gray-600 text-sm mt-1">Discover viral products before they peak using AI</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              ✕
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Platforms */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Research Platforms *
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {platformOptions.map(platform => (
                <label key={platform} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.platforms.includes(platform)}
                    onChange={(e) => handlePlatformChange(platform, e.target.checked)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="text-sm text-gray-700">{platform}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Product Categories (optional)
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {categoryOptions.map(category => (
                <label key={category} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.categories.includes(category)}
                    onChange={(e) => handleCategoryChange(category, e.target.checked)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="text-sm text-gray-700">{category}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Keywords */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Research Keywords
            </label>
            <input
              type="text"
              value={formData.keywords.join(", ")}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                keywords: e.target.value.split(",").map(k => k.trim()).filter(Boolean)
              }))}
              placeholder="viral, trending, gadget, problem-solving, etc."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Competition Level */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Competition Level
              </label>
              <select
                value={formData.competitionLevel}
                onChange={(e) => setFormData(prev => ({ ...prev, competitionLevel: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="Low">Low Competition Only</option>
                <option value="Medium">Low to Medium Competition</option>
                <option value="High">All Competition Levels</option>
              </select>
            </div>

            {/* Product Count */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Number of Products
              </label>
              <select
                value={formData.count}
                onChange={(e) => setFormData(prev => ({ ...prev, count: parseInt(e.target.value) }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={5}>5 Products</option>
                <option value={10}>10 Products</option>
                <option value={15}>15 Products</option>
                <option value={20}>20 Products</option>
              </select>
            </div>
          </div>

          {/* Results */}
          {results && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Research Results</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <div className="text-gray-600">Status</div>
                  <div className={`font-medium ${results.success ? 'text-green-600' : 'text-red-600'}`}>
                    {results.success ? 'Success' : 'Failed'}
                  </div>
                </div>
                <div>
                  <div className="text-gray-600">Products Found</div>
                  <div className="font-medium text-blue-600">{results.productsFound}</div>
                </div>
                <div>
                  <div className="text-gray-600">Products Added</div>
                  <div className="font-medium text-green-600">{results.productsAdded}</div>
                </div>
                <div>
                  <div className="text-gray-600">Success Rate</div>
                  <div className="font-medium text-purple-600">
                    {results.productsFound > 0 ? Math.round((results.productsAdded / results.productsFound) * 100) : 0}%
                  </div>
                </div>
              </div>
              {results.error && (
                <div className="mt-2 text-red-600 text-sm">{results.error}</div>
              )}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isResearching || formData.platforms.length === 0}
              className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {isResearching ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Researching...
                </>
              ) : (
                <>
                  🤖 Start AI Research
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
