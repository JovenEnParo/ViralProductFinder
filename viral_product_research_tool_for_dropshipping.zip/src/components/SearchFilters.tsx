interface SearchFiltersProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
  filters: {
    category: string;
    competitionLevel: string;
    minRating: number;
    sortBy: "rating" | "trendScore" | "recent";
  };
  onFiltersChange: (filters: any) => void;
  categories: string[];
}

export function SearchFilters({ 
  searchTerm, 
  onSearchChange, 
  filters, 
  onFiltersChange, 
  categories 
}: SearchFiltersProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow space-y-4">
      <div className="flex flex-col md:flex-row gap-4">
        {/* Search */}
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Category Filter */}
        <select
          value={filters.category}
          onChange={(e) => onFiltersChange({ ...filters, category: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="">All Categories</option>
          {categories.map(category => (
            <option key={category} value={category}>{category}</option>
          ))}
        </select>

        {/* Competition Filter */}
        <select
          value={filters.competitionLevel}
          onChange={(e) => onFiltersChange({ ...filters, competitionLevel: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="">All Competition</option>
          <option value="Low">Low Competition</option>
          <option value="Medium">Medium Competition</option>
          <option value="High">High Competition</option>
        </select>

        {/* Sort By */}
        <select
          value={filters.sortBy}
          onChange={(e) => onFiltersChange({ ...filters, sortBy: e.target.value })}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="rating">Sort by Rating</option>
          <option value="trendScore">Sort by Trend Score</option>
          <option value="recent">Sort by Recent</option>
        </select>
      </div>

      {/* Rating Filter */}
      <div className="flex items-center gap-4">
        <label className="text-sm font-medium text-gray-700">Min Rating:</label>
        <input
          type="range"
          min="0"
          max="5"
          step="0.5"
          value={filters.minRating}
          onChange={(e) => onFiltersChange({ ...filters, minRating: parseFloat(e.target.value) })}
          className="flex-1 max-w-xs"
        />
        <span className="text-sm text-gray-600">{filters.minRating}⭐</span>
      </div>
    </div>
  );
}
