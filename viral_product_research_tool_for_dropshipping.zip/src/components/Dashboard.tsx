import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { ProductTable } from "./ProductTable";
import { StatsCards } from "./StatsCards";
import { AddProductModal } from "./AddProductModal";
import { AIResearchModal } from "./AIResearchModal";
import { SearchFilters } from "./SearchFilters";

export function Dashboard() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAIModal, setShowAIModal] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [filters, setFilters] = useState({
    category: "",
    competitionLevel: "",
    minRating: 0,
    sortBy: "trendScore" as const
  });
  const [searchTerm, setSearchTerm] = useState("");

  const products = useQuery(api.products.listProducts, {
    category: filters.category || undefined,
    competitionLevel: filters.competitionLevel || undefined,
    minRating: filters.minRating || undefined,
    sortBy: filters.sortBy,
    limit: 50
  });

  const searchResults = useQuery(api.products.searchProducts, 
    searchTerm ? {
      searchTerm,
      category: filters.category || undefined,
      competitionLevel: filters.competitionLevel || undefined,
    } : "skip"
  );

  const stats = useQuery(api.products.getProductStats);
  const categories = useQuery(api.products.getCategories);

  const displayProducts = searchTerm ? searchResults : products;

  const handleProductsAdded = () => {
    setRefreshKey(prev => prev + 1);
    setShowAIModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Viral Product Research</h1>
          <p className="text-gray-600 mt-1">Discover trending products before they peak with AI-powered research</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setShowAIModal(true)}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2"
          >
            🤖 AI Research
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
          >
            Add Product
          </button>
        </div>
      </div>

      {/* Enhanced Stats Cards */}
      <StatsCards stats={stats} />

      {/* Quick Insights */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg border border-blue-200">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
            <span className="text-white text-sm">💡</span>
          </div>
          <h3 className="text-lg font-semibold text-gray-900">AI Research Insights</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="bg-white p-3 rounded-lg">
            <div className="text-blue-600 font-medium">🔥 Trending Now</div>
            <div className="text-gray-600">AI gadgets, smart home devices, and wellness products are dominating social media</div>
          </div>
          <div className="bg-white p-3 rounded-lg">
            <div className="text-green-600 font-medium">📈 Low Competition</div>
            <div className="text-gray-600">Pet tech and eco-friendly products show high potential with minimal competition</div>
          </div>
          <div className="bg-white p-3 rounded-lg">
            <div className="text-purple-600 font-medium">💰 High Profit</div>
            <div className="text-gray-600">Problem-solving gadgets under $50 have 3x+ markup potential</div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <SearchFilters
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        filters={filters}
        onFiltersChange={setFilters}
        categories={categories || []}
      />

      {/* Products Table */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-900">
              {searchTerm ? `Search Results (${displayProducts?.length || 0})` : 'Viral Products Database'}
            </h2>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              Live Data
            </div>
          </div>
        </div>
        <ProductTable products={displayProducts || []} />
      </div>

      {/* Modals */}
      {showAddModal && (
        <AddProductModal
          onClose={() => setShowAddModal(false)}
          categories={categories || []}
        />
      )}

      {showAIModal && (
        <AIResearchModal
          onClose={() => setShowAIModal(false)}
          onProductsAdded={handleProductsAdded}
        />
      )}
    </div>
  );
}
