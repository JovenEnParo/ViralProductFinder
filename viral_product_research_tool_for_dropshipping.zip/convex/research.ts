import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createResearchSession = mutation({
  args: {
    sessionName: v.string(),
    platforms: v.array(v.string()),
    keywords: v.array(v.string()),
    filters: v.object({
      minRating: v.number(),
      maxCompetition: v.string(),
      categories: v.array(v.string())
    })
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to create research session");
    }

    return await ctx.db.insert("research_sessions", {
      userId,
      sessionName: args.sessionName,
      platforms: args.platforms,
      keywords: args.keywords,
      filters: args.filters,
      results: [],
      createdAt: Date.now(),
    });
  },
});

export const getResearchSessions = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("research_sessions")
      .withIndex("by_user", q => q.eq("userId", userId))
      .order("desc")
      .take(10);
  },
});

export const createTrendAlert = mutation({
  args: {
    productId: v.id("products"),
    alertType: v.union(
      v.literal("price_drop"),
      v.literal("competition_change"),
      v.literal("viral_spike")
    ),
    threshold: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to create alerts");
    }

    return await ctx.db.insert("trend_alerts", {
      userId,
      productId: args.productId,
      alertType: args.alertType,
      threshold: args.threshold,
      isActive: true,
    });
  },
});

export const getTrendAlerts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const alerts = await ctx.db
      .query("trend_alerts")
      .withIndex("by_user", q => q.eq("userId", userId))
      .filter(q => q.eq(q.field("isActive"), true))
      .collect();

    // Get product details for each alert
    const alertsWithProducts = await Promise.all(
      alerts.map(async (alert) => {
        const product = await ctx.db.get(alert.productId);
        return {
          ...alert,
          product
        };
      })
    );

    return alertsWithProducts;
  },
});
