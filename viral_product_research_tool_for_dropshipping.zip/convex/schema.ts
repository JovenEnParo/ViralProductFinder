import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  products: defineTable({
    name: v.string(),
    description: v.string(),
    whyViral: v.string(),
    targetAudience: v.string(),
    competitionLevel: v.union(v.literal("Low"), v.literal("Medium"), v.literal("High")),
    profitabilityPotential: v.union(v.literal("Low"), v.literal("Medium"), v.literal("High")),
    sourceUrl: v.string(),
    sourcePlatform: v.string(),
    rating: v.number(), // 0-5 stars
    recommendation: v.string(),
    shouldTest: v.boolean(),
    category: v.string(),
    estimatedPrice: v.optional(v.number()),
    trendScore: v.number(), // 0-100
    addedBy: v.id("users"),
    isActive: v.boolean(),
    tags: v.array(v.string()),
  })
    .index("by_rating", ["rating"])
    .index("by_trend_score", ["trendScore"])
    .index("by_competition", ["competitionLevel"])
    .index("by_category", ["category"])
    .index("by_user", ["addedBy"])
    .searchIndex("search_products", {
      searchField: "name",
      filterFields: ["category", "competitionLevel", "sourcePlatform"]
    }),

  research_sessions: defineTable({
    userId: v.id("users"),
    sessionName: v.string(),
    platforms: v.array(v.string()),
    keywords: v.array(v.string()),
    filters: v.object({
      minRating: v.number(),
      maxCompetition: v.string(),
      categories: v.array(v.string())
    }),
    results: v.array(v.id("products")),
    createdAt: v.number(),
  }).index("by_user", ["userId"]),

  trend_alerts: defineTable({
    userId: v.id("users"),
    productId: v.id("products"),
    alertType: v.union(
      v.literal("price_drop"),
      v.literal("competition_change"),
      v.literal("viral_spike")
    ),
    isActive: v.boolean(),
    threshold: v.number(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
