"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";
import OpenAI from "openai";
import { internal } from "./_generated/api";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const researchViralProducts = action({
  args: {
    platforms: v.array(v.string()),
    categories: v.array(v.string()),
    keywords: v.array(v.string()),
    competitionLevel: v.optional(v.string()),
    count: v.optional(v.number())
  },
  handler: async (ctx, args): Promise<{
    success: boolean;
    productsFound: number;
    productsAdded: number;
    products: any[];
    error?: string;
  }> => {
    const platformsText = args.platforms.join(", ");
    const categoriesText = args.categories.length > 0 ? args.categories.join(", ") : "all categories";
    const keywordsText = args.keywords.length > 0 ? args.keywords.join(", ") : "trending products";
    const maxCompetition = args.competitionLevel || "Medium";
    const productCount = args.count || 10;

    const prompt = `You are an expert dropshipping product researcher. Find ${productCount} viral trending products RIGHT NOW from ${platformsText} in ${categoriesText} related to: ${keywordsText}.

CRITICAL REQUIREMENTS:
- Products must be currently trending (last 30 days)
- Competition level must be ${maxCompetition} or lower
- Focus on products with high profit potential (3x+ markup possible)
- Exclude oversaturated products already dominating Amazon top charts
- Prioritize unique, problem-solving, entertaining, or emotional-trigger products

For each product, provide EXACTLY this JSON format:
{
  "products": [
    {
      "name": "Product Name",
      "description": "Detailed product description (50-100 words)",
      "whyViral": "Why it's trending and viral appeal (30-50 words)",
      "targetAudience": "Specific target demographic",
      "competitionLevel": "Low|Medium|High",
      "profitabilityPotential": "Low|Medium|High",
      "sourceUrl": "https://example.com/source",
      "sourcePlatform": "Platform name",
      "rating": 4.5,
      "recommendation": "Test recommendation with reasoning (30-50 words)",
      "shouldTest": true,
      "category": "Product category",
      "estimatedPrice": 29.99,
      "trendScore": 85,
      "tags": ["tag1", "tag2", "tag3"]
    }
  ]
}

Focus on products that are:
- Currently viral on social media
- Have low competition on Google/Facebook Ads
- Solve real problems or provide entertainment
- Have strong emotional appeal or wow factor
- Can be sourced from AliExpress/Alibaba at low cost
- Have potential for 3x+ markup

Return ONLY valid JSON, no additional text.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7,
        max_tokens: 4000
      });

      const content = response.choices[0].message.content;
      if (!content) {
        throw new Error("No content received from AI");
      }

      // Parse the JSON response
      let parsedData;
      try {
        parsedData = JSON.parse(content);
      } catch (parseError) {
        // Try to extract JSON from the response if it's wrapped in other text
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          parsedData = JSON.parse(jsonMatch[0]);
        } else {
          throw new Error("Could not parse AI response as JSON");
        }
      }

      if (!parsedData.products || !Array.isArray(parsedData.products)) {
        throw new Error("Invalid response format from AI");
      }

      // Add products to database
      const addedProducts = [];
      for (const product of parsedData.products) {
        try {
          const productId: any = await ctx.runMutation(internal.products.addAIProduct, {
            ...product,
            estimatedPrice: product.estimatedPrice || undefined,
            tags: product.tags || []
          });
          addedProducts.push({ ...product, _id: productId });
        } catch (error) {
          console.error("Error adding product:", error);
          // Continue with other products
        }
      }

      return {
        success: true,
        productsFound: parsedData.products.length,
        productsAdded: addedProducts.length,
        products: addedProducts
      };

    } catch (error) {
      console.error("AI Research Error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
        productsFound: 0,
        productsAdded: 0,
        products: []
      };
    }
  },
});

export const analyzeProductTrends = action({
  args: {
    productName: v.string(),
    category: v.string()
  },
  handler: async (ctx, args) => {
    const prompt = `Analyze the current trend status and market potential for "${args.productName}" in the ${args.category} category.

Provide analysis on:
1. Current trend momentum (0-100 score)
2. Competition level assessment
3. Profit margin potential
4. Target audience insights
5. Marketing angle recommendations
6. Seasonal factors
7. Risk assessment

Format as JSON:
{
  "trendScore": 85,
  "competitionLevel": "Medium",
  "profitPotential": "High",
  "targetAudience": "Detailed audience description",
  "marketingAngles": ["angle1", "angle2", "angle3"],
  "seasonality": "Analysis of seasonal factors",
  "risks": ["risk1", "risk2"],
  "recommendation": "Overall recommendation with reasoning"
}`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.3,
        max_tokens: 1000
      });

      const content = response.choices[0].message.content;
      if (!content) {
        throw new Error("No content received from AI");
      }

      return JSON.parse(content);
    } catch (error) {
      console.error("Trend Analysis Error:", error);
      return {
        error: error instanceof Error ? error.message : "Analysis failed"
      };
    }
  },
});
