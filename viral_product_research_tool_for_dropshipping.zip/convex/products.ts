import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listProducts = query({
  args: {
    limit: v.optional(v.number()),
    category: v.optional(v.string()),
    competitionLevel: v.optional(v.string()),
    minRating: v.optional(v.number()),
    sortBy: v.optional(v.union(v.literal("rating"), v.literal("trendScore"), v.literal("recent")))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let query = ctx.db.query("products").filter(q => q.eq(q.field("isActive"), true));

    if (args.category) {
      query = query.filter(q => q.eq(q.field("category"), args.category));
    }

    if (args.competitionLevel) {
      query = query.filter(q => q.eq(q.field("competitionLevel"), args.competitionLevel));
    }

    if (args.minRating !== undefined && args.minRating > 0) {
      query = query.filter(q => q.gte(q.field("rating"), args.minRating!));
    }

    // Apply sorting and get results
    let products;
    if (args.sortBy === "rating") {
      products = await ctx.db.query("products")
        .withIndex("by_rating")
        .filter(q => q.eq(q.field("isActive"), true))
        .order("desc")
        .take(args.limit || 50);
    } else if (args.sortBy === "trendScore") {
      products = await ctx.db.query("products")
        .withIndex("by_trend_score")
        .filter(q => q.eq(q.field("isActive"), true))
        .order("desc")
        .take(args.limit || 50);
    } else {
      products = await query.order("desc").take(args.limit || 50);
    }

    return products;
  },
});

export const searchProducts = query({
  args: {
    searchTerm: v.string(),
    category: v.optional(v.string()),
    competitionLevel: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let searchQuery = ctx.db
      .query("products")
      .withSearchIndex("search_products", q => q.search("name", args.searchTerm));

    if (args.category) {
      searchQuery = searchQuery.filter(q => q.eq(q.field("category"), args.category));
    }

    if (args.competitionLevel) {
      searchQuery = searchQuery.filter(q => q.eq(q.field("competitionLevel"), args.competitionLevel));
    }

    return await searchQuery.take(20);
  },
});

export const addProduct = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    whyViral: v.string(),
    targetAudience: v.string(),
    competitionLevel: v.union(v.literal("Low"), v.literal("Medium"), v.literal("High")),
    profitabilityPotential: v.union(v.literal("Low"), v.literal("Medium"), v.literal("High")),
    sourceUrl: v.string(),
    sourcePlatform: v.string(),
    rating: v.number(),
    recommendation: v.string(),
    shouldTest: v.boolean(),
    category: v.string(),
    estimatedPrice: v.optional(v.number()),
    trendScore: v.number(),
    tags: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to add products");
    }

    return await ctx.db.insert("products", {
      ...args,
      addedBy: userId,
      isActive: true,
    });
  },
});

export const addAIProduct = internalMutation({
  args: {
    name: v.string(),
    description: v.string(),
    whyViral: v.string(),
    targetAudience: v.string(),
    competitionLevel: v.union(v.literal("Low"), v.literal("Medium"), v.literal("High")),
    profitabilityPotential: v.union(v.literal("Low"), v.literal("Medium"), v.literal("High")),
    sourceUrl: v.string(),
    sourcePlatform: v.string(),
    rating: v.number(),
    recommendation: v.string(),
    shouldTest: v.boolean(),
    category: v.string(),
    estimatedPrice: v.optional(v.number()),
    trendScore: v.number(),
    tags: v.array(v.string()),
    addedBy: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    // For AI-generated products, we'll use a system user or the first available user
    let userId = args.addedBy;
    if (!userId) {
      // Get the first user as a fallback for AI-generated products
      const users = await ctx.db.query("users").take(1);
      if (users.length > 0) {
        userId = users[0]._id;
      } else {
        throw new Error("No users found to assign AI-generated product");
      }
    }

    return await ctx.db.insert("products", {
      name: args.name,
      description: args.description,
      whyViral: args.whyViral,
      targetAudience: args.targetAudience,
      competitionLevel: args.competitionLevel,
      profitabilityPotential: args.profitabilityPotential,
      sourceUrl: args.sourceUrl,
      sourcePlatform: args.sourcePlatform,
      rating: args.rating,
      recommendation: args.recommendation,
      shouldTest: args.shouldTest,
      category: args.category,
      estimatedPrice: args.estimatedPrice,
      trendScore: args.trendScore,
      tags: args.tags,
      addedBy: userId,
      isActive: true,
    });
  },
});

export const updateProduct = mutation({
  args: {
    productId: v.id("products"),
    updates: v.object({
      rating: v.optional(v.number()),
      trendScore: v.optional(v.number()),
      competitionLevel: v.optional(v.union(v.literal("Low"), v.literal("Medium"), v.literal("High"))),
      profitabilityPotential: v.optional(v.union(v.literal("Low"), v.literal("Medium"), v.literal("High"))),
      recommendation: v.optional(v.string()),
      shouldTest: v.optional(v.boolean()),
      isActive: v.optional(v.boolean()),
    })
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to update products");
    }

    const product = await ctx.db.get(args.productId);
    if (!product || product.addedBy !== userId) {
      throw new Error("Product not found or access denied");
    }

    await ctx.db.patch(args.productId, args.updates);
  },
});

export const getTopProducts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const topRated = await ctx.db
      .query("products")
      .withIndex("by_rating")
      .filter(q => q.eq(q.field("isActive"), true))
      .order("desc")
      .take(5);

    const topTrending = await ctx.db
      .query("products")
      .withIndex("by_trend_score")
      .filter(q => q.eq(q.field("isActive"), true))
      .order("desc")
      .take(5);

    const lowCompetition = await ctx.db
      .query("products")
      .withIndex("by_competition")
      .filter(q => q.and(
        q.eq(q.field("isActive"), true),
        q.eq(q.field("competitionLevel"), "Low")
      ))
      .order("desc")
      .take(5);

    return {
      topRated,
      topTrending,
      lowCompetition
    };
  },
});

export const getCategories = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const products = await ctx.db
      .query("products")
      .filter(q => q.eq(q.field("isActive"), true))
      .collect();

    const categories = [...new Set(products.map(p => p.category))];
    return categories.sort();
  },
});

export const getProductStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const products = await ctx.db
      .query("products")
      .filter(q => q.eq(q.field("isActive"), true))
      .collect();

    const totalProducts = products.length;
    const lowCompetition = products.filter(p => p.competitionLevel === "Low").length;
    const highPotential = products.filter(p => p.profitabilityPotential === "High").length;
    const shouldTest = products.filter(p => p.shouldTest).length;
    const avgRating = products.reduce((sum, p) => sum + p.rating, 0) / totalProducts || 0;
    const avgTrendScore = products.reduce((sum, p) => sum + p.trendScore, 0) / totalProducts || 0;

    return {
      totalProducts,
      lowCompetition,
      highPotential,
      shouldTest,
      avgRating: Math.round(avgRating * 10) / 10,
      avgTrendScore: Math.round(avgTrendScore)
    };
  },
});
